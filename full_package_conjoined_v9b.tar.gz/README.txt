Native GENIE splines with Cooper-Sarkar-Mertsch-Sarkar (CSMS) neutrino
cross-sections for high energy neutrino deep inelastic scattering (DIS)
interactions.

For example, to generate 5000 events in each of which a 300 GeV muon neutrino
interacts with water(88.79% O16, 11.21% H1):
gevgen -n 5000 -e 300 -p 14 --cross-sections /path_to_spline/full_package_conjoined_v9b.xml -t 1000080160[0.8879],1000010010[0.1121]

For detailed documentation of this native GENIE with CSMS high energy neutrino
cross-section, please refer to https://github.com/plt109/csms_genie

Pueh Leng Tan, 5 February 2019
